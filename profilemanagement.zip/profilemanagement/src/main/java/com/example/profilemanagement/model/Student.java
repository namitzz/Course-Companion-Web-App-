package com.example.profilemanagement.model;

import jakarta.persistence.*;

@Entity
public class Student {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private String email;
    private String course;
    private String preferences;

    public Student() {}

    public Student(String name, String email, String course, String preferences) {
        this.name = name;
        this.email = email;
        this.course = course;
        this.preferences = preferences;
    }

    public Long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public String getCourse() {
        return course;
    }

    public String getPreferences() {
        return preferences;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setCourse(String course) {
        this.course = course;
    }

    public void setPreferences(String preferences) {
        this.preferences = preferences;
    }
}
