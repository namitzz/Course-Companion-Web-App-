package com.example.profilemanagement.controller;

import com.example.profilemanagement.model.Student;
import com.example.profilemanagement.service.StudentService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;

@Controller
public class StudentController {
    private final StudentService studentService;

    public StudentController(StudentService studentService) {
        this.studentService = studentService;
    }

    // 🏠 Main Page (Dashboard)
    @GetMapping("/")
    public String showDashboard(Model model) {
        List<Student> students = studentService.getAllStudents();
        model.addAttribute("students", students);
        return "dashboard"; // Loads dashboard.html
    }

    // Add New Student
    @PostMapping("/addStudent")
    public String addStudent(@RequestParam String name, @RequestParam String email) {
        Student student = new Student();
        student.setName(name);
        student.setEmail(email);
        studentService.saveStudent(student);
        return "redirect:/";
    }

    // Delete Student
    @GetMapping("/deleteStudent/{id}")
    public String deleteStudent(@PathVariable Long id) {
        studentService.deleteStudent(id);
        return "redirect:/";
    }

    // Update Student Page
    @GetMapping("/editStudent/{id}")
    public String editStudent(@PathVariable Long id, Model model) {
        Student student = studentService.getStudentById(id);
        model.addAttribute("student", student);
        return "editStudent"; // Loads editStudent.html
    }

    // Save Updated Student Info
    @PostMapping("/updateStudent")
    public String updateStudent(@RequestParam Long id, @RequestParam String name, @RequestParam String email) {
        Student student = studentService.getStudentById(id);
        student.setName(name);
        student.setEmail(email);
        studentService.saveStudent(student);
        return "redirect:/";
    }
}
